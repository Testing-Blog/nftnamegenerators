export default interface PlanI {
  id: string;
  price: number;
  assetsNumber: number;
  features: string;
}
