type NetworkType = "eth" | "sol" | "pol"

export default NetworkType
