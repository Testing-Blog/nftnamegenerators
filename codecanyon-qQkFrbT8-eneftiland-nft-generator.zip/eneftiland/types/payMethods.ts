type payMethodsType = "paypal" | "metamask" | "stripe" | "razorpay" | undefined

export default payMethodsType
