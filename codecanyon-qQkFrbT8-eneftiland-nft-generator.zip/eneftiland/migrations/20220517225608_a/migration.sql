-- AlterTable
ALTER TABLE `plan` ADD COLUMN `watermark` BOOLEAN NOT NULL DEFAULT false;
