-- AlterTable
ALTER TABLE `user` ADD COLUMN `password` VARCHAR(250) NULL;
