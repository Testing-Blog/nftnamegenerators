-- AlterTable
ALTER TABLE `user` ADD COLUMN `metamaskAddress` VARCHAR(191) NULL;
