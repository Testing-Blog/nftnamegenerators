-- AlterTable
ALTER TABLE `settings` ADD COLUMN `facebookId` VARCHAR(191) NULL,
    ADD COLUMN `facebookSecret` VARCHAR(191) NULL;
