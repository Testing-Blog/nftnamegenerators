-- AlterTable
ALTER TABLE `privacypage` MODIFY `content` VARCHAR(60000) NOT NULL;

-- AlterTable
ALTER TABLE `termspage` MODIFY `content` VARCHAR(60000) NOT NULL;
