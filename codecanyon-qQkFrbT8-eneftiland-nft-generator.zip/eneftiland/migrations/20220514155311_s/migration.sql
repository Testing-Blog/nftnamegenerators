-- AlterTable
ALTER TABLE `account` MODIFY `provider` VARCHAR(191) NULL,
    MODIFY `providerAccountId` VARCHAR(191) NULL;
