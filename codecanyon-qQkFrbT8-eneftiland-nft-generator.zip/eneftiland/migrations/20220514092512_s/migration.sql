-- AlterTable
ALTER TABLE `metatags` MODIFY `ogType` VARCHAR(191) NULL,
    MODIFY `ogTitle` VARCHAR(191) NULL,
    MODIFY `ogDesc` VARCHAR(191) NULL,
    MODIFY `ogUrl` VARCHAR(191) NULL,
    MODIFY `twitterTitle` VARCHAR(191) NULL,
    MODIFY `twitterDesc` VARCHAR(191) NULL,
    MODIFY `twitterSite` VARCHAR(191) NULL,
    MODIFY `twitterCreator` VARCHAR(191) NULL,
    MODIFY `desc` VARCHAR(191) NULL,
    MODIFY `keywords` VARCHAR(191) NULL;
