/*
  Warnings:

  - You are about to drop the column `databaseUrl` on the `settings` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `settings` DROP COLUMN `databaseUrl`;
