-- AlterTable
ALTER TABLE `settings` ADD COLUMN `googleAnalyticsTrackingCode` VARCHAR(191) NULL;
