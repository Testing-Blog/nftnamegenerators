-- AlterTable
ALTER TABLE `settings` ADD COLUMN `isMetamaskAuth` BOOLEAN NOT NULL DEFAULT false;
