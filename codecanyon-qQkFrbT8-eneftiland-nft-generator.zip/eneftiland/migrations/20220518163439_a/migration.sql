-- AlterTable
ALTER TABLE `collection` MODIFY `paymentMethod` VARCHAR(191) NULL;
