-- AlterTable
ALTER TABLE `settings` ADD COLUMN `watermarkText` VARCHAR(191) NULL DEFAULT 'watermark';
